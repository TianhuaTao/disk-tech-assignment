#!/bin/bash

./single_thread_test
echo --------------------------------------
./multi_thread_test
echo --------------------------------------
./crash_test
